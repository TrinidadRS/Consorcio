<?php
    class Proveedor
    {
        private $cod;
        private $nom;
        private $tel;
        private $cor;
        private $dir;
        private $rep;
        private $ruc;
        private $rub;
        
        public function __GET($k){
            return $this->$k;
        }
        public function __SET($k,$v){
            return $this->$k = $v;
        }
    }
?>